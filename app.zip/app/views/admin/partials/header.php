<?php
/**
 * Header Partial for Admin Panel
 * Tuân thủ nguyên tắc MVC/OOP
 */
?>
<?php include __DIR__ . '/../components/header.html'; ?>
