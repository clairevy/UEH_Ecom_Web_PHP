<?php
/**
 * Sidebar Partial for Admin Panel
 * Tuân thủ nguyên tắc MVC/OOP
 */
// echo ROOT; exit;
?>
<?php include ROOT . 'components/sidebar.html'; ?>
